<?php
// openwa-demo/backend/openwa_config.php
//
// CONFIGURACIÓN. Lo único que tenés que cambiar está marcado con "CAMBIAR ACÁ".
// Este archivo vive en el servidor: nadie lo ve desde la app.

// --- OpenWA ---------------------------------------------------------
// CAMBIAR ACÁ: la URL donde corre OpenWA (puerto por defecto: 2785)
define('OPENWA_BASE_URL', 'http://localhost:2785');
// CAMBIAR ACÁ: la API key que OpenWA mostró en el primer arranque
define('OPENWA_API_KEY', 'owa_k1_4fb10f6fe5aff19517bebb26857a0a02f260443e74e0d890fb6f9b87ef7f72b3');
// CAMBIAR ACÁ: el id de la sesión que vinculaste escaneando el QR
define('OPENWA_SESSION_ID', '52906cda-d122-425f-abf0-58530793e3d7');

// --- Interruptor general (kill-switch) ------------------------------
// Si lo ponés en false, no se envía NADA. Sirve para "apagar" rápido.
define('RECORDATORIOS_ACTIVOS', true);

// --- Base de datos --------------------------------------------------
// CAMBIAR ACÁ: los datos de tu MySQL (XAMPP por defecto: root sin contraseña)
define('DB_HOST', 'localhost');
define('DB_NAME', 'openwa_demo');
define('DB_USER', 'root');
define('DB_PASS', '');

// --- Log ------------------------------------------------------------
// Ahí se anota todo lo que pasa. No hace falta tocar.
define('LOG_PATH', __DIR__ . '/logs/recordatorios.log');

// --- Ruta al php.exe (para lanzar en segundo plano) -----------------
// CAMBIAR ACÁ si tu XAMPP/PHP vive en otro lado. Se usa para correr
// send_reminders.php en segundo plano (dispatch y lazy sweep).
// XAMPP en Windows suele ser: C:\xampp\php\php.exe
// Si lo dejás vacío (''), se intenta detectar solo.
define('PHP_CLI_PATH', 'G:\apps\xampp\php\php.exe');
